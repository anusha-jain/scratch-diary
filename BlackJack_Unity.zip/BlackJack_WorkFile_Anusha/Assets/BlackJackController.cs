﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //remember to write this always

public class BlackJackController : MonoBehaviour
{
    //global objects here
    InputField NameInput;
    InputField BankInput;
    InputField BetInput;
    int Bank;
    int Bet;
    int Push;
    Text Display;
    Image ImagePlayerCard1;
    Image ImagePlayerCard2;
    Image ImagePlayerCard3;
    Image ImagePlayerCard4;
    Image ImagePlayerCard5;
    Image ImagePlayerCard6;
    Button PlayerStay;
    Button PlayerHit;
    Button PlayerDeal;
    bool HasAcePlayer = false;
    int NextDeckCard = 0;
    int PlayerCount = 0;
    int PlayerScore = 0;
    int CurrentCard;


    Image ImageDealerCard1;
    Image ImageDealerCard2;
    Image ImageDealerCard3;
    Image ImageDealerCard4;
    Image ImageDealerCard5;
    Image ImageDealerCard6;
    int DealerScore = 0;
    int DealerCount = 0;
    int DealerHiddenCard;
    bool HasAceDealer = false;


    bool Pushbet = false;
    private int[] DeckValues = { 1,1,1,1, 10,10,10,10, 10,10,10,10, 10,10,10,10, 
            10,10,10,10, 9,9,9,9, 8,8,8,8, 7,7,7,7 ,6,6,6,6, 5,5,5,5,
            4,4,4,4, 3,3,3,3, 2,2,2,2}; //card values acc to card order
    int[] DeckAsInts = new int[52]; //array to shuffle cards

    // Start is called before the first frame update
    void Start()
    {
        NameInput = GameObject.Find("Canvas/NameBox").GetComponent<InputField>();
        BankInput = GameObject.Find("Canvas/BankBox").GetComponent<InputField>();
        BetInput = GameObject.Find("Canvas/BetBox").GetComponent<InputField>();
        Display = GameObject.Find("Canvas/DisplayResult").GetComponent<Text>();

        //Player Cards

        ImagePlayerCard1 = GameObject.Find("Canvas/ImagePlayerCard1").GetComponent<Image>();

        ImagePlayerCard2 = GameObject.Find("Canvas/ImagePlayerCard2").GetComponent<Image>();

        ImagePlayerCard3 = GameObject.Find("Canvas/ImagePlayerCard3").GetComponent<Image>();
        ImagePlayerCard3.gameObject.SetActive(false); /*hides the card but keeps it 
        ready for HIT*/

        ImagePlayerCard4 = GameObject.Find("Canvas/ImagePlayerCard4").GetComponent<Image>();
        ImagePlayerCard4.gameObject.SetActive(false);

        ImagePlayerCard5 = GameObject.Find("Canvas/ImagePlayerCard5").GetComponent<Image>();
        ImagePlayerCard5.gameObject.SetActive(false);

        ImagePlayerCard6 = GameObject.Find("Canvas/ImagePlayerCard6").GetComponent<Image>();
        ImagePlayerCard6.gameObject.SetActive(false);

        //Dealer Cards

        ImageDealerCard1 = GameObject.Find("Canvas/ImageDealerCard1").GetComponent<Image>();

        ImageDealerCard2 = GameObject.Find("Canvas/ImageDealerCard2").GetComponent<Image>();

        ImageDealerCard3 = GameObject.Find("Canvas/ImageDealerCard3").GetComponent<Image>();
        ImageDealerCard3.gameObject.SetActive(false);

        ImageDealerCard4 = GameObject.Find("Canvas/ImageDealerCard4").GetComponent<Image>();
        ImageDealerCard4.gameObject.SetActive(false);

        ImageDealerCard5 = GameObject.Find("Canvas/ImageDealerCard5").GetComponent<Image>();
        ImageDealerCard5.gameObject.SetActive(false);

        ImageDealerCard6 = GameObject.Find("Canvas/ImageDealerCard6").GetComponent<Image>();
        ImageDealerCard6.gameObject.SetActive(false);

        //Buttons

        PlayerStay = GameObject.Find("Canvas/ButtonStay").GetComponent<Button>();
        PlayerStay.interactable = false;

        PlayerHit = GameObject.Find("Canvas/ButtonHit").GetComponent<Button>();
        PlayerHit.interactable = false;

        PlayerDeal = GameObject.Find("Canvas/ButtonDeal").GetComponent<Button>();

        for (int i = 0; i < 52; i++) //fill array with numbers
        {
            DeckAsInts[i] = i;
        }
        Shuffle(DeckAsInts); //Create the method later
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void HandleButtonClickedDeal ()
    {
        Debug.Log("In HandleButtonClickedDeal()");
        BankInput.readOnly = true;
        BetInput.readOnly = true;
        ImagePlayerCard3.gameObject.SetActive(false);
        ImagePlayerCard4.gameObject.SetActive(false);
        ImagePlayerCard5.gameObject.SetActive(false);
        ImagePlayerCard6.gameObject.SetActive(false);

        ImageDealerCard2.sprite = Resources.Load<Sprite>("blueBackVertical");
        ImageDealerCard3.gameObject.SetActive(false);
        ImageDealerCard4.gameObject.SetActive(false);
        ImageDealerCard5.gameObject.SetActive(false);
        ImageDealerCard6.gameObject.SetActive(false);

        Bank = System.Convert.ToInt32(BankInput.text);
        Bet = System.Convert.ToInt32(BetInput.text);
        Bet = Mathf.Clamp(Bet, 1, Bank);
        Push = Bet;

        if(Pushbet==true)
        {
            Bet = Push + Bet;
            Pushbet=false;
        }

        if (NextDeckCard > 45) //fresh card deck
        {
            NextDeckCard = 0; //reset new deck if not enough cards for round
            Shuffle(DeckAsInts); //reshuffle deck
        }

        PlayerCount = 0;
        PlayerScore = 0;
        DealerCount = 0;
        DealerScore = 0;

        CurrentCard = DeckAsInts[NextDeckCard]; //first shuffled card
        ImagePlayerCard1.sprite = Resources.Load<Sprite>("card" + CurrentCard);
        PlayerScore = PlayerScore + DeckValues[CurrentCard];
        if (DeckValues[CurrentCard] == 1) HasAcePlayer = true; //deal with aces
        PlayerCount++;
        NextDeckCard++;

        CurrentCard = DeckAsInts[NextDeckCard]; //first shuffled card
        ImageDealerCard1.sprite = Resources.Load<Sprite>("card" + CurrentCard);
        DealerScore = DealerScore + DeckValues[CurrentCard];
        if (DeckValues[CurrentCard] == 1) HasAceDealer = true; //deal with aces
        DealerCount++;
        NextDeckCard++;

        CurrentCard = DeckAsInts[NextDeckCard]; //second shuffled card
        ImagePlayerCard2.sprite = Resources.Load<Sprite>("card" + CurrentCard);
        PlayerScore = PlayerScore + DeckValues[CurrentCard];
        if (DeckValues[CurrentCard] == 1) HasAcePlayer = true; //deal with aces
        PlayerCount++;
        NextDeckCard++;
        
        CurrentCard = DeckAsInts[NextDeckCard]; //first shuffled card
        DealerHiddenCard = CurrentCard;
        DealerScore = DealerScore + DeckValues[DealerHiddenCard]; //revealed in Stay
        if (DeckValues[CurrentCard] == 1) HasAceDealer = true; //deal with aces
        DealerCount++;
        NextDeckCard++;

        Debug.Log(PlayerScore);
        PlayerHit.interactable = true;
        PlayerStay.interactable = true;

        if (updateForAce(PlayerScore, HasAcePlayer) == 21)
        {
            Display.text = NameInput.text + " Wins!";
            Bank = Bank + Bet;
            PlayerCount = 0;
            DealerCount = 0;
            PlayerScore = 0;
            DealerScore = 0;
            PlayerHit.interactable = false;
            PlayerStay.interactable = false;
            BetInput.readOnly = false;
            BankInput.text = Bank.ToString();
            return;
        }

        Display.text = "Your Hand is worth " + PlayerScore.ToString();
    }

    public void HandleButtonClickedHit()
    {
        Debug.Log("In HandleButtonClickedHit()");
        CurrentCard = DeckAsInts[NextDeckCard];
        PlayerScore = PlayerScore + DeckValues[CurrentCard];
        Display.text = "Your Hand is worth " + PlayerScore.ToString();
        PlayerCount++;
        NextDeckCard++;
        if (DeckValues[CurrentCard] == 1) HasAcePlayer = true; //deal with aces

        switch (PlayerCount)
        {
            case 3:
                ImagePlayerCard3.gameObject.SetActive(true);
                ImagePlayerCard3.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                break;
            case 4:
                ImagePlayerCard4.gameObject.SetActive(true);
                ImagePlayerCard4.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                break;
            case 5:
                ImagePlayerCard5.gameObject.SetActive(true);
                ImagePlayerCard5.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                break;
            case 6:
                ImagePlayerCard6.gameObject.SetActive(true);
                ImagePlayerCard6.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                break;
        }

        if (PlayerScore > 21)
        {
            PlayerHit.interactable = false;
            Display.text = NameInput.text + " Busts \n" +
                    "Dealer Wins!";
            Bank = Bank - Bet;
            BankInput.text = Bank.ToString();
            if(Bank <= 0)
        {
                Display.text = Display.text + "\n" + "You have no more money to bet!\n" +
                    "Please enter Bank, your Bet, and Press Deal";
                BankInput.readOnly = false;
                BetInput.readOnly = false;
                PlayerStay.interactable = false;
            }
            return;
        }

        Debug.Log(PlayerScore);
    }

    public void HandleButtonClickedStay()
    {
        Debug.Log("In HandleButtonClickedStay()");
        PlayerHit.interactable = false;
        PlayerStay.interactable = false;
        ImageDealerCard2.sprite = Resources.Load<Sprite>("card" + DealerHiddenCard);
        while (DealerScore <17)
        {
            CurrentCard = DeckAsInts[NextDeckCard];
            DealerScore = DealerScore + DeckValues[CurrentCard];
            DealerCount++;
            NextDeckCard++;
            if (DeckValues[CurrentCard] == 1) HasAcePlayer = true; //deal with aces
           

            switch (DealerCount)
            {
                case 3:
                    ImageDealerCard3.gameObject.SetActive(true);
                    ImageDealerCard3.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                    break;
                case 4:
                    ImageDealerCard4.gameObject.SetActive(true);
                    ImageDealerCard4.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                    break;
                case 5:
                    ImageDealerCard5.gameObject.SetActive(true);
                    ImageDealerCard5.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                    break;
                case 6:
                    ImageDealerCard6.gameObject.SetActive(true);
                    ImageDealerCard6.sprite = Resources.Load<Sprite>("card" + CurrentCard);
                    break;
            }
        }

        if (DealerScore > 21)
        {
            if (PlayerScore > 21)
            {
                Display.text = NameInput.text +" and Dealer Bust \n" +
                    "Dealer Wins!";
                Bank = Bank - Bet;
            } else
            {
                Display.text = "Dealer Bust \n" +
                    NameInput.text + " Wins!";
                Bank = Bank + Bet;
            }
        } else
        {
            if (PlayerScore > 21)
            {
                Display.text = NameInput.text + " Busts \n" +
                    "Dealer Wins!";
                Bank = Bank - Bet;
            }
            else if (updateForAce(PlayerScore, HasAcePlayer) > updateForAce(DealerScore, HasAceDealer))
            {
                Bank = Bank + Bet;
                Display.text = NameInput.text + " Wins!";
            }
            else if (updateForAce(PlayerScore, HasAcePlayer) == updateForAce(DealerScore, HasAceDealer))
            {
                Pushbet = true;
                Display.text = "It's a Push! \n" + 
                    "Deal Again";
            }
            else
            {
                Bank = Bank - Bet;
                Display.text = "Dealer Wins!";
            }
        }

          Debug.Log(DealerScore); //check loop todo remove later
        BankInput.text = Bank.ToString();

        if (Bank <= 0)
        {
            Display.text = "You have no more money to bet!\n" + 
                "Please enter Bank, your Bet, and Press Deal";
            BankInput.readOnly = false;
            BetInput.readOnly = false;
            PlayerStay.interactable = false;
        }
    }

    public static void Shuffle<T>(T[] array)
    {
        for (int i = array.Length; i > 1; i--) //starts at back of array
        {
            // Pick random element to swap.
            int j = Random.Range(0, i); // 0 <= j <= i-1
                                        // Swap.
            T tmp = array[j];
            array[j] = array[i - 1];
            array[i - 1] = tmp;
        }
    } // Shuffle

    private int updateForAce(int score, bool hasAce)
    {
        if (hasAce)
        {
            if ((score + 10) <= 21)
                return score + 10;
        }
        return score;
    }
}
